let nome = 'Zé do Taxão'
console.log(nome)