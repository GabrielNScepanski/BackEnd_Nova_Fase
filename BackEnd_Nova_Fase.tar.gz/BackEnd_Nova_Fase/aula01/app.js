const lh = require ('lodash')
console.log (lh.random (1,10))